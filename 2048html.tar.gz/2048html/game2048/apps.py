from django.apps import AppConfig


class Game2048Config(AppConfig):
    name = 'game2048'
